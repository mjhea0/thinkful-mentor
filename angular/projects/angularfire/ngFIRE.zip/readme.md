```sh
$ npm install
$ bower install
$ gulp
```